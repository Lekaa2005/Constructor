package practise;
public class constructor {
    int rnum;
    String name;
    public constructor(String name) {
    	this(1,name); }
    public constructor(int rnum,String name) {
    	this.rnum=rnum;
    	this.name=name;
    	}
    public void printInfo() {   //printinfo can pass multiple parameters
    	System.out.println("Roll no:" + rnum + ", Name:" +name);
    }
	public static void main(String[] args) {
		constructor s1=new constructor("ram");
		constructor s2=new constructor(2,"venu");
		s1.printInfo();
		s2.printInfo();
	}
}   //method overloading : two constructors with the same name but different parameters. 


